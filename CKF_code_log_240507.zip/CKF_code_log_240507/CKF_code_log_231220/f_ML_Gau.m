function f = f_ML_Gau(measTol,nodeLoc_pre,posAnc,dim,varMeas,nodeLoc_last,R_tol,statTrans,statIn,accIni,meaIdx,lam)
Q = varMeas.*eye(2);
pk = posAnc;
y = nodeLoc_pre(1:dim);
x = nodeLoc_pre(dim+1:2*dim);
s = x - pk;
yn = y;
hstep = [norm(s);s'*yn/norm(s)];
% f = -1/2*(measTol - hstep)'*(Q\(measTol - hstep));
f = (measTol - hstep)'*(Q\(measTol - hstep));
%%
% lamIdx = 0;
% for jj = 0:meaIdx-1
%     lamIdx = lamIdx + lam^(2*jj);
% end
mu = statTrans*nodeLoc_last + lam^(meaIdx-2)*statIn*accIni;
g = (nodeLoc_pre-mu)'*(R_tol\(nodeLoc_pre-mu));
f = real(f + g);


