
clear
rng(123)
dim = 3; %维度
numElement = 2*dim;
numMea = 200;   %测量次数
numVair = 2;    %观测量个数
monTimes = 100;1e3;
numPoc = 1;
%加速度部分
numGau = 3;
varPhiInit = zeros(numGau,1);

timDelta = 0.1;    %两个锚点测量时的时间间隔

delPosAP = 100;

numSamplePF = 200;

varDis = 0.09; %观测量方差
varSpe = 1;

varPhiInit(1) = 0.09; %输入量方差
varPhiInit(2) = 0.09;
varPhiInit(3) = 0;

phiMeanInit1 = [2 2 0]'; %输入量均值
phiMeanInit2 = [-2 -2 0]';
phiMeanInit3 = zeros(dim,1);

Prob1 = 0.2;
Prob2 = 0.2;
Prob3 = 1 - Prob1 - Prob2;
Prob = [Prob1 Prob2 Prob3];

numIter = 5e2;      % 迭代次数
minNum = 1e-6;      % 牛顿迭代阈值
devLocUpdateFinal = zeros(numVair,numMea);
devLocUpdateMag_Final = zeros(numVair,numMea);
devLocKal_Final = zeros(numVair,numMea);
devLocPF_Final = zeros(numVair,numMea);
devLocSCKF_Final = zeros(numVair,numMea);


%状态转移矩阵
statTransSca = [1 0;timDelta 1];
statTrans = kron(statTransSca,eye(dim));
statInSca = [timDelta 1/2*timDelta^2]';
statIn = kron(statInSca,eye(dim));

acc = zeros(dim,numMea+1);
accMean = zeros(3*dim,numMea+1);
varAcc1 = zeros(dim,numMea+1);
varAcc2 = zeros(dim,numMea+1);
varAcc3 = zeros(dim,numMea+1);
varAcc1(:,1) = varPhiInit(1)*ones(dim,1);
varAcc2(:,1) = varPhiInit(2)*ones(dim,1);
varAcc3(:,1) = varPhiInit(3)*ones(dim,1);

phiPdf1 = phiMeanInit1 + sqrt(varPhiInit(1))*randn(dim,1);
phiPdf2 = phiMeanInit2 + sqrt(varPhiInit(2))*randn(dim,1);
phiPdf3 = phiMeanInit3 + sqrt(varPhiInit(3))*randn(dim,1);

chi = randsrc(dim,1,[1,2,3;Prob1,Prob2,Prob3]);
phiPdf = zeros(dim,numMea+1);
phiMean = zeros(dim,numMea+1);%输入的均值

phiPdf(:,1) = phiPdf1.*(chi==1)+phiPdf2.*(chi==2)+phiPdf3.*(chi==3);
acc(:,1) = phiPdf(:,1);
accMean(:,1) = [phiMeanInit1' phiMeanInit2' phiMeanInit3']';


varStatFir = varPhiInit(1);
nodeLocUpdate = zeros(numElement,numMea+1);
nodeLocUpdate(:,1) = zeros(numElement,1);


crbIni = 1e-2*eye(numElement);

crbFinal = zeros(2,numMea);
crbIniIdx = 1e-1*sqrt(varAcc1(1,1)*dim)*ones(2,1);
crbFinal(:,1) = crbIniIdx;

crbFinal1 = zeros(2,numMea);
crbFinal1(:,1) = crbIniIdx;

crbFinalSCKF = zeros(2,numMea);
crbFinalSCKF(:,1) = crbIniIdx;

varEKFFinal = zeros(2,numMea);
varEKFFinal(:,1) = crbIniIdx;

nodeCKFEst(:,1) = nodeLocUpdate(:,1) + sqrtm(crbIni)*randn(numElement,1);

nodeLocEst = zeros(dim,numMea+1);
nodeLocEst(:,1) = nodeCKFEst(dim+1:end,1);

nodeLocEst1 = zeros(dim,numMea+1);
nodeLocEst1(:,1) = nodeLocUpdate(dim+1:2*dim,1);

devLocUpdateFinal(:,1) = crbIniIdx;
devLocUpdateMag_Final(:,1) = crbIniIdx;
devLocKal_Final(:,1) = crbIniIdx;

for monIdx = 1:1:monTimes
    % 真实路径
    for meaIdx = 2:1:numMea+1
        chi = randsrc(dim,1,[1,2,3;Prob1,Prob2,Prob3]);
        phiPdf1 = phiMeanInit1 + sqrt(varPhiInit(1))*randn(dim,1);
        phiPdf2 = phiMeanInit2 + sqrt(varPhiInit(2))*randn(dim,1);
        phiPdf3 = phiMeanInit3 + sqrt(varPhiInit(3))*randn(dim,1);
        accMean(:,meaIdx) = accMean(:,1);
        acc(:,meaIdx) = phiPdf1.*(chi==1)+phiPdf2.*(chi==2)+phiPdf3.*(chi==3);

        varAcc1(:,meaIdx) = varAcc1(:,1);
        varAcc2(:,meaIdx) = varAcc2(:,1);
        varAcc3(:,meaIdx) = varAcc3(:,1);

        nodeLocUpdate(:,meaIdx) = statTrans*nodeLocUpdate(:,meaIdx-1) + statIn*acc(:,meaIdx-1);
    end

    % 锚点位置

    networkLim = zeros(dim,2);
    for idx = 1:dim
        networkLim(idx,1) = min(nodeLocUpdate(dim+idx,:));
        networkLim(idx,2) = max(nodeLocUpdate(dim+idx,:));
    end

    
    squSize = 2e3;

    for idx = 1:dim
        networkLim(idx,1) = floor(networkLim(idx,1))-delPosAP;
    end

    networkLim(1,2) = networkLim(1,1) + squSize;
    networkLim(2,2) = networkLim(2,1) + squSize;
    networkLim(3,2) = networkLim(3,1) + 2*delPosAP;
    %     numGrid = squSize/delOrder;

    dim1 = (networkLim(1,1):delPosAP:networkLim(1,2));
    dim2 = (networkLim(2,1):delPosAP:networkLim(2,2));
    dim3 = (networkLim(3,1):delPosAP:networkLim(3,2));

    L1 = length(dim1);
    L2 = length(dim2);
    L3 = length(dim3);

    numAP = L1*L2*L3;
    posAP = zeros(dim,numAP);

    sign = 1;
    for idx1 = 1:L1
        for idx2 = 1:L2
            for idx3 = 1:L3
                posAP(:,sign) = [dim1(idx1) dim2(idx2) dim3(idx3)]';
                sign = sign + 1;
            end
        end
    end
    1;
% 
    monTimesReal = monTimes;


    flag = 0;
    tic
    % CKF ---initialize
    crbTol = zeros(numElement,numMea);
    crbTol1 = zeros(numElement,numMea);

    locErr = zeros(2,numIter,numMea);
    devLocUpdate = zeros(2,numMea);
    nodeLoc_last = nodeCKFEst(:,1);
    R_tol = zeros(2*dim,2*dim*numMea);
    M_tol = zeros(2*dim,2*dim*numMea);
    S_tol = zeros(2*dim,2*dim*numMea);
    R_tol(:,2*dim+1:2*dim*2) = statTrans*crbIni*statTrans' + statIn*diag(varAcc1(:,1))*statIn';
    M_tol(:,2*dim+1:2*dim*2) = statTrans*crbIni*statTrans' + statIn*diag(varAcc2(:,1))*statIn';
    S_tol(:,2*dim+1:2*dim*2) = statTrans*crbIni*statTrans' + statIn*diag(varAcc3(:,3))*statIn';

    % CKF2 --- Initialize
    locErr1 = zeros(2,numIter,numMea);
    devLocUpdate1 = zeros(2,numMea);
    nodeLoc_last1 = nodeCKFEst(:,1);
    R_tol1 = zeros(2*dim,2*dim*numMea);
    M_tol1 = zeros(2*dim,2*dim*numMea);
    S_tol1 = zeros(2*dim,2*dim*numMea);
    R_tol1(:,2*dim+1:2*dim*2) = statTrans*crbIni*statTrans' + statIn*diag(varAcc1(:,1))*statIn';
    M_tol1(:,2*dim+1:2*dim*2) = statTrans*crbIni*statTrans' + statIn*diag(varAcc2(:,1))*statIn';
    S_tol1(:,2*dim+1:2*dim*2) = statTrans*crbIni*statTrans' + statIn*diag(varAcc3(:,3))*statIn';

    %   EKF - initialize the variables
    statForeEKF = zeros(2*dim,numMea);
    statForeEKF(:,1) = randn(2*dim,1);
    statEstEKF = zeros(2*dim,numMea+1);
    statEstEKF(:,1) = nodeCKFEst(:,1);
    devLocKal = zeros(2,numMea);
    R_tol_Kal = statTrans*crbIni*statTrans' + statIn*diag(varAcc1(:,1))*statIn';
    M_tol_Kal = statTrans*crbIni*statTrans' + statIn*diag(varAcc2(:,1))*statIn';
    S_tol_Kal = statTrans*crbIni*statTrans' + statIn*diag(varAcc3(:,3))*statIn';
    P = Prob1*R_tol_Kal + Prob2*M_tol_Kal + Prob3*S_tol_Kal;


    %   SCKF - initialize the variables
    statForeSCKF = zeros(2*dim,numMea);
    statForeSCKF(:,1) = randn(2*dim,1);
    statEstSCKF = zeros(2*dim,numMea+1);
    statEstSCKF(:,1) = nodeCKFEst(:,1);
    devLocSCKF = zeros(2,numMea);
    R_tol_SCKF = zeros(2*dim,2*dim*numMea);
    M_tol_SCKF = zeros(2*dim,2*dim*numMea);
    S_tol_SCKF = zeros(2*dim,2*dim*numMea);
    R_tol_SCKF(:,2*dim+1:2*dim*2) = statTrans*crbIni*statTrans' + statIn*diag(varAcc1(:,1))*statIn';
    M_tol_SCKF(:,2*dim+1:2*dim*2) = statTrans*crbIni*statTrans' + statIn*diag(varAcc2(:,1))*statIn';
    S_tol_SCKF(:,2*dim+1:2*dim*2) = statTrans*crbIni*statTrans' + statIn*diag(varAcc3(:,3))*statIn';
    crbTolSCKF = zeros(numElement,numMea);


    %   PF - initialize the variables
    
    nodeLocPF_Sample = zeros(numElement,numSamplePF);
    for PFstep = 1:1:numSamplePF
        nodeLocPF_Sample(:,PFstep) = nodeLocUpdate(:,1) + sqrt(varStatFir)*randn(numElement,1);
    end
    meaUpdatePF = zeros(2,numSamplePF);
    preWeightPF = zeros(1,numSamplePF);
    nodeEstPF = zeros(numElement,numMea);
    nodeEstPF(:,1) =  nodeCKFEst(:,1);
    devLocPF = zeros(2,numMea);

    relDisTol = zeros(numMea,2);

    posAncTol = zeros(dim,numMea);
    for meaIdx = 2:1:numMea
%         meaIdx
        R_acc = diag(varAcc1(:,meaIdx));
        M_acc = diag(varAcc2(:,meaIdx));
        S_acc = diag(varAcc3(:,meaIdx));

        % 随机寻找最近的k个AP中的一个
        relDisIdx = zeros(numAP,1);
        for idx = 1:numAP
            relDisIdx(idx) = norm(nodeLocUpdate(dim+1:end,meaIdx)-posAP(:,idx));
        end

        [~,sign] = mink(relDisIdx,10);
        sign = randsrc(1,1,sign');
        
        % 测量
        posAnc = posAP(:,sign); %锚点位置
        
        posAncTol(:,meaIdx) = posAnc;
        varMeas = [varDis;varSpe];
        noiMeas = sqrt(varMeas).*randn(2,1);
        measTol = mea_trans(nodeLocUpdate(:,meaIdx),posAnc,dim); %距离与相对速度关系式（测量量）
        relDisTol(meaIdx,1) = measTol(1);
        relDisTol(meaIdx,2) = sign;
        measTol = measTol + noiMeas;  %加噪声后的测量量

        %EKF
        statForeEKF(:,meaIdx) = statTrans*statEstEKF(:,meaIdx-1) + Prob1*statIn*accMean(1:dim,meaIdx) + Prob2*statIn*accMean(dim+1:2*dim,meaIdx) + Prob3*statIn*accMean(2*dim+1:3*dim,meaIdx);
        DeltaVar = Prob1*statIn*accMean(1:dim,meaIdx)*(statIn*accMean(1:dim,meaIdx))' + ...
            Prob2*statIn*accMean(dim+1:2*dim,meaIdx)*(statIn*accMean(dim+1:2*dim,meaIdx))' + ...
            Prob3*statIn*accMean(2*dim+1:3*dim,meaIdx)*(statIn*accMean(2*dim+1:3*dim,meaIdx))' - ...
            (statForeEKF(:,meaIdx) - statTrans*statEstEKF(:,meaIdx-1))*((statForeEKF(:,meaIdx) - statTrans*statEstEKF(:,meaIdx-1)))';
        P_fore = DeltaVar + statTrans*P*statTrans'+ Prob1*statIn*R_acc*statIn' + Prob2*statIn*M_acc*statIn' + Prob3*statIn*S_acc*statIn';
        h = partial_h(statForeEKF(:,meaIdx),posAnc,dim);
        K = P_fore*h'/(h*P_fore*h'+ kron(diag(varMeas),eye(numPoc)));
        statEstEKF(:,meaIdx) = statForeEKF(:,meaIdx) + K*(measTol - mea_trans(statForeEKF(:,meaIdx),posAnc,dim));
        P = (eye(2*dim)-K*h)*P_fore*(eye(2*dim)-K*h)'+ K*diag(varMeas)*K';
        varEKFIdx = diag(P);
        varEKFFinal(1,meaIdx) = varEKFFinal(1,meaIdx) + sum(varEKFIdx(1:dim));
        varEKFFinal(2,meaIdx) = varEKFFinal(2,meaIdx) + sum(varEKFIdx(dim+1:2*dim));

        devLocKal(1,meaIdx) = norm(statEstEKF(1:dim,meaIdx) - nodeLocUpdate(1:dim,meaIdx))^2;
        devLocKal(2,meaIdx) = norm(statEstEKF(dim+1:2*dim,meaIdx) - nodeLocUpdate(dim+1:2*dim,meaIdx))^2;


        %SCKF
        PCKF = Prob1*R_tol_SCKF(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx) + Prob2*M_tol_SCKF(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx) + Prob3*S_tol_SCKF(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx);
        statForeSCKF(:,meaIdx) = statTrans*statEstSCKF(:,meaIdx-1) + Prob1*statIn*accMean(1:dim,meaIdx) + Prob2*statIn*accMean(dim+1:2*dim,meaIdx) + Prob3*statIn*accMean(2*dim+1:3*dim,meaIdx);
        DeltaVar = Prob1*statIn*accMean(1:dim,meaIdx)*(statIn*accMean(1:dim,meaIdx))' + ...
            Prob2*statIn*accMean(dim+1:2*dim,meaIdx)*(statIn*accMean(dim+1:2*dim,meaIdx))' + ...
            Prob3*statIn*accMean(2*dim+1:3*dim,meaIdx)*(statIn*accMean(2*dim+1:3*dim,meaIdx))' - ...
            (statForeSCKF(:,meaIdx) - statTrans*statEstSCKF(:,meaIdx-1))*((statForeSCKF(:,meaIdx) - statTrans*statEstSCKF(:,meaIdx-1)))';
        
        P_fore = statTrans*PCKF*statTrans'+ Prob1*statIn*R_acc*statIn' + Prob2*statIn*M_acc*statIn' + Prob3*statIn*S_acc*statIn';
        h = partial_h(statForeSCKF(:,meaIdx),posAnc,dim);
        K = P_fore*h'/(h*P_fore*h'+ kron(diag(varMeas),eye(numPoc)));
        statEstSCKF(:,meaIdx) = statForeSCKF(:,meaIdx) + K*(measTol - mea_trans(statForeSCKF(:,meaIdx),posAnc,dim));
        devLocSCKF(1,meaIdx) = norm(statEstSCKF(1:dim,meaIdx) - nodeLocUpdate(1:dim,meaIdx))^2;
        devLocSCKF(2,meaIdx) = norm(statEstSCKF(dim+1:2*dim,meaIdx) - nodeLocUpdate(dim+1:2*dim,meaIdx))^2;
        [crb,~] = CRB(statEstSCKF(:,meaIdx),posAnc,varMeas,statEstSCKF(:,meaIdx-1),statTrans,statIn,accMean(:,meaIdx),R_tol_SCKF(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),M_tol_SCKF(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),S_tol_SCKF(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),Prob,dim);
        crb = 1.02*crb;
        crbTolSCKF(:,meaIdx) = diag(crb);
        crbFinalSCKF(1,meaIdx) = crbFinalSCKF(1,meaIdx) + sum(crbTolSCKF(1:dim,meaIdx));
        crbFinalSCKF(2,meaIdx) = crbFinalSCKF(2,meaIdx) + sum(crbTolSCKF(dim+1:2*dim,meaIdx));
        R_tol_SCKF(:,2*dim*meaIdx+1:2*dim*(meaIdx+1)) = statTrans*crb*statTrans' + statIn*R_acc*statIn';
        M_tol_SCKF(:,2*dim*meaIdx+1:2*dim*(meaIdx+1)) = statTrans*crb*statTrans' + statIn*M_acc*statIn';
        S_tol_SCKF(:,2*dim*meaIdx+1:2*dim*(meaIdx+1)) = statTrans*crb*statTrans' + statIn*S_acc*statIn';

%         %PF
%         accMean1 = accMean(1:dim,meaIdx);
%         accMean2 = accMean(dim+1:2*dim,meaIdx);
%         accMean3 = accMean(2*dim+1:3*dim,meaIdx);
%         for PFstep = 1:1:numSamplePF
%             chi = randsrc(dim,1,[1,2,3;Prob1,Prob2,Prob3]);
%             pdf1 = accMean1 + sqrt(varAcc1(:,meaIdx)).*randn(dim,1);
%             pdf2 = accMean2 + sqrt(varAcc2(:,meaIdx)).*randn(dim,1);
%             pdf3 = accMean3 + sqrt(varAcc3(:,meaIdx)).*randn(dim,1);
%             accPF = pdf1.*(chi==1)+pdf2.*(chi==2)+pdf3.*(chi==3);
%             nodeLocPF_Sample(:,PFstep) = statTrans*nodeLocPF_Sample(:,PFstep) + statIn*accPF;
%             meaUpdatePF(:,PFstep) = mea_trans(nodeLocPF_Sample(:,PFstep),posAnc,dim);
%             Q = varMeas.*eye(2);
%             preWeightPF(PFstep) = 1/sqrt((2*pi)^2*det(Q)) * exp(-1/2*(measTol - meaUpdatePF(:,PFstep))'*(Q\(measTol - meaUpdatePF(:,PFstep))));
%         end
% 
%         preWeightPF = preWeightPF/sum(preWeightPF);
% 
% %         for PFstep = 1:1:numSamplePF
% %             nodeLocPF_Sample(:,PFstep) = nodeLocPF_Sample(:,find(rand <= cumsum(preWeightPF,2),1));   % 粒子权重大的将多得到后代
% %         end
% 
%         RPF = cumsum(preWeightPF,2);
%         TPF = rand(1,numSamplePF);
%         [~,~,reSamStep1] = histcounts(TPF,RPF);
%         nodeLocPF_Sample = nodeLocPF_Sample(:,reSamStep1+1);
% 
%         nodeEstPF(:,meaIdx) = sum(nodeLocPF_Sample,2)/numSamplePF;
%         devLocPF(1,meaIdx) = norm(nodeEstPF(1:dim,meaIdx) - nodeLocUpdate(1:dim,meaIdx))^2;
%         devLocPF(2,meaIdx) = norm(nodeEstPF(dim+1:2*dim,meaIdx) - nodeLocUpdate(dim+1:2*dim,meaIdx))^2;
% 
        %CKF
        nodeLoc_pre = nodeLoc_last;
        for nn = 1:1:numIter
            [df,Hes] = Hessian(measTol,nodeLoc_pre,posAnc,dim,varMeas,nodeLoc_last,R_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),M_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),S_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),statTrans,statIn,accMean(:,meaIdx),Prob);
            if isnan(Hes)
                flag = 1;
                break
            end
            Hes = (Hes+Hes')/2;
            [V,S] = eig(Hes);
            ev = diag(S);
            V1 = V(:,ev>0);
            e1 = ev(ev>0);
            u_nt = -V1*((V1'*df)./e1);

            % 回溯直线法 alpha∈[0.01,0.3],beta∈[0.1,0.8]
            step = 1;
            alpha = 0.03;
            beta = 0.8;
            while 1
                nodeLoc_delta = nodeLoc_pre + step*u_nt;
                f = f_ML(measTol,nodeLoc_pre,posAnc,dim,varMeas,nodeLoc_last,R_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),M_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),S_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),statTrans,statIn,accMean(:,meaIdx),Prob);
                f_delta = f_ML(measTol,nodeLoc_delta,posAnc,dim,varMeas,nodeLoc_last,R_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),M_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),S_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),statTrans,statIn,accMean(:,meaIdx),Prob);
                stt = alpha*step*df'*u_nt;
                sss = f + stt;
                if f_delta > sss
                    step = beta*step;
                else
                    break
                end
            end
            nodeLoc_pre = nodeLoc_delta;

            locErr(1,nn,meaIdx) = norm(nodeLoc_pre(1:dim) - nodeLocUpdate(1:dim,meaIdx))^2;
            locErr(2,nn,meaIdx) = norm(nodeLoc_pre(dim+1:2*dim) - nodeLocUpdate(dim+1:2*dim,meaIdx))^2;

            if u_nt'*u_nt < minNum       % 梯度下降减量足够小时提前减少迭代
                break
            end
            if nn == numIter
                fprintf('CKF does not converge\n');
                monIdx
                meaIdx
            end
        end
        devLocUpdate(:,meaIdx) = locErr(:,nn,meaIdx);
        [crb,~] = CRB(nodeLoc_pre,posAnc,varMeas,nodeLoc_last,statTrans,statIn,accMean(:,meaIdx),R_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),M_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),S_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),Prob,dim);

        crbTol(:,meaIdx) = diag(crb);
        crbFinal(1,meaIdx) = crbFinal(1,meaIdx) + sum(crbTol(1:dim,meaIdx));
        crbFinal(2,meaIdx) = crbFinal(2,meaIdx) + sum(crbTol(dim+1:2*dim,meaIdx));
        R_tol(:,2*dim*meaIdx+1:2*dim*(meaIdx+1)) = statTrans*crb*statTrans' + statIn*R_acc*statIn';
        M_tol(:,2*dim*meaIdx+1:2*dim*(meaIdx+1)) = statTrans*crb*statTrans' + statIn*M_acc*statIn';
        S_tol(:,2*dim*meaIdx+1:2*dim*(meaIdx+1)) = statTrans*crb*statTrans' + statIn*S_acc*statIn';
        nodeLoc_last = nodeLoc_pre;
        nodeCKFEst(:,meaIdx) = nodeLoc_pre;
        nodeLocEst(:,meaIdx) = nodeLoc_pre(dim+1:2*dim);
% 
% 
%         %%%%%%% CKF2
%         nodeLoc_pre1 = nodeLoc_last1;
%         for nn = 1:1:numIter
%             [df,Hes] = Hessian(measTol,nodeLoc_pre1,posAnc,dim,varMeas,nodeLoc_last1,R_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),M_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),S_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),statTrans,statIn,accMean(:,meaIdx),Prob);
%             if isnan(Hes)
%                 flag = 1;
%                 break
%             end
%             Hes = (Hes+Hes')/2;
%             [V,S] = eig(Hes);
%             ev = diag(S);
%             V1 = V(:,ev>0);
%             e1 = ev(ev>0);
%             u_nt = -V1*((V1'*df)./e1);
% 
%             % 回溯直线法 alpha∈[0.01,0.3],beta∈[0.1,0.8]
%             step = 1;
%             alpha = 0.03;
%             beta = 0.8;
%             while 1
%                 nodeLoc_delta1 = nodeLoc_pre1 + step*u_nt;
%                 f = f_ML(measTol,nodeLoc_pre1,posAnc,dim,varMeas,nodeLoc_last1,R_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),M_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),S_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),statTrans,statIn,accMean(:,meaIdx),Prob);
%                 f_delta = f_ML(measTol,nodeLoc_delta1,posAnc,dim,varMeas,nodeLoc_last1,R_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),M_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),S_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),statTrans,statIn,accMean(:,meaIdx),Prob);
%                 stt = alpha*step*df'*u_nt;
%                 sss = f + stt;
%                 if f_delta > sss
%                     step = beta*step;
%                 else
%                     break
%                 end
%             end
%             nodeLoc_pre1 = nodeLoc_delta1;
% 
%             locErr1(1,nn,meaIdx) = norm(nodeLoc_pre1(1:dim) - nodeLocUpdate(1:dim,meaIdx))^2;
%             locErr1(2,nn,meaIdx) = norm(nodeLoc_pre1(dim+1:2*dim) - nodeLocUpdate(dim+1:2*dim,meaIdx))^2;
% 
%             if u_nt'*u_nt < minNum       % 梯度下降减量足够小时提前减少迭代
%                 break
%             end
%         end
%         devLocUpdate1(:,meaIdx) = locErr1(:,nn,meaIdx);
%         [crb,F] = CRB(nodeLoc_pre1,posAnc,varMeas,nodeLoc_last1,statTrans,statIn,accMean(:,meaIdx),R_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),M_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),S_tol1(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),Prob,dim);
% 
%         crbTol1(:,meaIdx) = diag(crb);
%         crbFinal1(1,meaIdx) = crbFinal1(1,meaIdx) + sum(crbTol1(1:dim,meaIdx));
%         crbFinal1(2,meaIdx) = crbFinal1(2,meaIdx) + sum(crbTol1(dim+1:2*dim,meaIdx));
%         crb = 1.02*crb;
%         R_tol1(:,2*dim*meaIdx+1:2*dim*(meaIdx+1)) = statTrans*crb*statTrans' + statIn*R_acc*statIn';
%         M_tol1(:,2*dim*meaIdx+1:2*dim*(meaIdx+1)) = statTrans*crb*statTrans' + statIn*M_acc*statIn';
%         S_tol1(:,2*dim*meaIdx+1:2*dim*(meaIdx+1)) = statTrans*crb*statTrans' + statIn*S_acc*statIn';
%         nodeLoc_last1 = nodeLoc_pre1;
%         nodeLocEst1(:,meaIdx) = nodeLoc_pre1(dim+1:2*dim);



    end
%     if flag == 1
        %         monTimesReal = monTimesReal - 1;
%         fprintf('the numer of Monte Carlo is%6.1f\n',monIdx)

%     else
        devLocUpdateFinal = devLocUpdateFinal + devLocUpdate;
        devLocUpdateMag_Final = devLocUpdateMag_Final + devLocUpdate1;
        devLocKal_Final = devLocKal_Final + devLocKal;
        devLocPF_Final = devLocPF_Final + devLocPF;
        devLocSCKF_Final = devLocSCKF_Final + devLocSCKF;    
        fprintf('the numer of Monte Carlo is%6.1f\n',monIdx)

%     end
    toc
end

devLocUpdateFinal = sqrt(devLocUpdateFinal/monTimesReal);
devLocUpdateMag_Final = sqrt(devLocUpdateMag_Final/monTimesReal);
crbFinal = sqrt(crbFinal/monTimesReal);
crbFinal1 = sqrt(crbFinal1/monTimesReal);
crbFinalSCKF = sqrt(crbFinalSCKF/monTimesReal);
varEKFFinal = sqrt(varEKFFinal/monTimesReal);
devLocKal_Final = sqrt(devLocKal_Final/monTimesReal);
devLocPF_Final = sqrt(devLocPF_Final/monTimesReal);
devLocSCKF_Final = sqrt(devLocSCKF_Final/monTimesReal);

% LL = length(posAncTol(1,:));
% figure
% for idx = 1:LL
%     plot(posAncTol(1,idx),posAncTol(2,idx),'o');
%     hold on
% end
% 
% figure
% for idx = 1:numAP
%     plot(posAP(1,idx),posAncTol(2,idx),'o');
%     hold on
% end

Time = (2*timDelta:timDelta:numMea*timDelta);

figure
subplot(2,1,1)
plot(Time,devLocUpdateFinal(1,2:end),'b','linewidth',2.3);
hold on
plot(Time,devLocUpdateMag_Final(1,2:end),'r','linewidth',2.3);
hold on
plot(Time,devLocSCKF_Final(1,2:end),'m','linewidth',2.3);
hold on
plot(Time,devLocKal_Final(1,2:end),'color',[0.00,0.79,0.14],'linewidth',2.3);
hold on
plot(Time,devLocPF_Final(1,2:end),'color',[0.93,0.69,0.13],'linewidth',2.3);
hold on
plot(Time,real(crbFinal(1,2:end)),'b','linestyle','--','linewidth',2.3);
hold on
plot(Time,real(crbFinalSCKF(1,2:end)),'m','linestyle','--','linewidth',2.3);
hold on
plot(Time,varEKFFinal(1,2:end),'color',[0.00,0.79,0.14],'linestyle','--','linewidth',2)
hold on
ylabel('RMSE (m/s)')
xlabel('Time (s)')
legend('CKF','CKF2','SCKF','EKF','PF','CRB-CKF','CRB-SCKF','var-EKF')
title('Velocity Estimation')
set(gca,'FontSize',13);
grid on
hold on

subplot(2,1,2)
plot(Time,devLocUpdateFinal(2,2:end),'b','linewidth',2.3);
hold on
plot(Time,devLocUpdateMag_Final(2,2:end),'r','linewidth',2.3);
hold on
plot(Time,devLocSCKF_Final(2,2:end),'m','linewidth',2.3);
hold on
plot(Time,devLocKal_Final(2,2:end),'color',[0.00,0.79,0.14],'linewidth',2.3);
hold on
plot(Time,devLocPF_Final(2,2:end),'color',[0.93,0.69,0.13],'linewidth',2.3);
hold on
plot(Time,real(crbFinal(2,2:end)),'b','linestyle','--','linewidth',2.3);
hold on
plot(Time,real(crbFinalSCKF(2,2:end)),'m','linestyle','--','linewidth',2.3);
hold on
plot(Time,varEKFFinal(2,2:end),'color',[0.00,0.79,0.14],'linestyle','--','linewidth',2)
hold on
ylabel('RMSE (m)')
xlabel('Time (s)')
legend('CKF','CKF2','SCKF','EKF','PF','CRB-CKF','CRB-SCKF','var-EKF')
title('Position Estimation')
set(gca,'FontSize',13);
grid on
name = ['SCKF2_a=' num2str(abs(phiMeanInit1(1))) '_' num2str(abs(phiMeanInit1(2))) '_' num2str(abs(phiMeanInit1(3)))...
    ';p=' num2str(Prob1) '_' num2str(Prob2) ...
    ';gridDel=' num2str(delPosAP) ';varMea=' num2str(varDis) ';DeltaT=' num2str(timDelta) ...
    ';MonTimes=' num2str(monTimesReal) '.fig'];
saveas(gcf,name);