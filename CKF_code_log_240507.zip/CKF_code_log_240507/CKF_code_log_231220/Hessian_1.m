function [df,Hes] = Hessian_1(measTol,nodeLoc_pre,posAnc,dim,varMeas,nodeLoc_last,R_tol,S_tol,statTrans,Prob)

dk = measTol(1);
vk = measTol(2);
t = 0;
Dk = varMeas(1);
Dkk = varMeas(2);
Q = varMeas.*eye(2);
pk = posAnc;
y = nodeLoc_pre(1:dim);
x = nodeLoc_pre(dim+1:2*dim);
s = x - pk;
yn = y;
%% h(x,y,a)��x��һ�׵�
dhx_1 = s/norm(s);
dhx_2 = (yn/norm(s) - s'*yn*s/norm(s)^3);
dhx = [dhx_1 dhx_2];

%% h(x,y,a)��y��һ�׵�
dhy_1 = t*s/norm(s);
dhy_2 = (s+t*yn)/norm(s) - s'*yn*s*t/norm(s)^3;
dhy = [dhy_1 dhy_2];

dh = [dhy;dhx];

%% f(x,y,a)��x����׵�����fxx
%f1����
ddfxx_1 = -2/Dk*((dk/norm(s)-1)*eye(dim) - dk*s*(s)'/norm(s)^3);

%f2����
G1 = -vk*yn*(s)'/norm(s)^3;
G2 = -vk*((s*yn'+(s)'*yn*eye(dim))/(norm(s))^3 - 3*(s)'*yn*s*(s)'/(norm(s))^5);
G3 = -1*(yn*yn')/norm(s)^2 + 2*(s)'*yn*yn*(s)'/norm(s)^4;
G4 = 2*(s)'*yn*s*yn'/norm(s)^4 + ((s)'*yn)^2*eye(dim)/norm(s)^4 - 4*((s)'*yn)^2*(s*(s)')/norm(s)^6;
ddfxx_2 = -2/Dkk*(G1+G2+G3+G4);

ddfxx = ddfxx_1+ddfxx_2;

%% f(x,y,a)��y����׵�����fyy
%f1����
ddfyy_1 = -2/Dk*((dk/norm(s)-1)*t^2*eye(dim) - dk*t^2*s*(s)'/norm(s)^3);

%f2����
S1 = 2*vk*t*eye(dim)/norm(s) - vk*t*(s+t*yn)*(s)'/norm(s)^3;
S2 = -1*((s+t*yn)*(s+t*yn)'+ 2*t*(s)'*yn*eye(dim))/norm(s)^2 + 2*t*(s)'*yn*(s+t*yn)*(s)'/norm(s)^4;
S3 = t*(2*(s)'*yn*s*(s+t*yn)'+t*((s)'*yn)^2*eye(dim))/norm(s)^4 - 4*t^2*((s)'*yn)^2*s*(s)'/norm(s)^6;
S4 = -1*vk*t*((s*(s+t*yn)'+t*(s)'*yn*eye(dim))/norm(s)^3 - 3*t*(s)'*yn*(s*s')/norm(s)^5);
ddfyy_2 = -2/Dkk*(S1+S2+S3+S4);

ddfyy = ddfyy_1 + ddfyy_2;

%% ddfyx
%f1����
ddfyx_1 = -2/Dk*((dk/norm(s)-1)*t*eye(dim)-dk*t*(s*s')/norm(s)^3);

%f2����
N1 = vk/norm(s)*(eye(dim) - (s+t*yn)*s'/norm(s)^2);
N2 = -1*vk*t/norm(s)^3*(s*yn'+s'*yn*eye(dim)-3*s'*yn*(s*s')/norm(s)^2);
N3 = -1/norm(s)^2*((s+t*yn)*yn'+s'*yn*eye(dim))+2/norm(s)^4*s'*yn*(s+t*yn)*s';
N4 = t/norm(s)^4*(2*s'*yn*s*yn'+(s'*yn)^2*eye(dim)-4*(s'*yn)^2*(s*s')/norm(s)^2);
ddfyx_2 = -2/Dkk*(N1+N2+N3+N4);

ddfyx = ddfyx_1+ddfyx_2;
ddfxy = ddfyx';


hstep = [norm(s);s'*yn/norm(s)];
df = dh*(Q\(measTol - hstep));
Hes = -1/2*[ddfyy ddfyx;ddfxy ddfxx];
%%
f = 1/sqrt((2*pi)^2*det(Q))*exp(-1/2*(measTol - hstep)'*(Q\(measTol - hstep)));

numElement = 2*dim;
P = Prob;
mu = statTrans*nodeLoc_last;

M = P/sqrt((2*pi)^numElement*det(R_tol));
N = (1-P)/sqrt((2*pi)^numElement*det(S_tol));

f1 = M*exp(-1/2*(nodeLoc_pre - mu)'*(R_tol\(nodeLoc_pre - mu)));
f2 = N*exp(-1/2*(nodeLoc_pre - mu)'*(S_tol\(nodeLoc_pre - mu)));
g1 = -R_tol\(nodeLoc_pre - mu);
g2 = -S_tol\(nodeLoc_pre - mu);

df = f*df*(f1+f2) + f*(f1*g1+f2*g2);
Hes = f*(df*df')*(f1+f2) + f*Hes*(f1+f2) + 2*f*df*(f1*g1+f2*g2)' + ...
    f*(f1*(g1*g1') - f1*(R_tol\eye(numElement)) + f2*(g2*g2') - f2*(S_tol\eye(numElement)));
