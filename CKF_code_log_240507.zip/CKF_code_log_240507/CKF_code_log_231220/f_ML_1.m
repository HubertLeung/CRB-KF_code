function f = f_ML_1(measTol,nodeLoc_pre,posAnc,dim,varMeas,nodeLoc_last,R_tol,S_tol,statTrans,Prob)

Q = varMeas.*eye(2);
pk = posAnc;
y = nodeLoc_pre(1:dim);
x = nodeLoc_pre(dim+1:2*dim);
s = x - pk;
yn = y;
hstep = [norm(s);s'*yn/norm(s)];
q = -1/2*(measTol - hstep)'*(Q\(measTol - hstep));
f1 = 1/sqrt((2*pi)^2*det(Q))*exp(q);

numElement = 2*dim;
P = Prob;
mu = statTrans*nodeLoc_last;

M = P/sqrt((2*pi)^numElement*det(R_tol));
N = (1-P)/sqrt((2*pi)^numElement*det(S_tol));
f2 = M*exp(-1/2*(nodeLoc_pre - mu)'*(R_tol\(nodeLoc_pre - mu)))+...
    N*exp(-1/2*(nodeLoc_pre - mu)'*(S_tol\(nodeLoc_pre - mu)));
f = f1*f2;


