clc
clear
dim = 3; %维度
numElement = 2*dim;
numMea = 300;    %测量次数
monTimes = 1e2;
timDelta = 0.1;    %两个锚点测量时的时间间隔
numPoc = 1;
numVair = 2;

delPosAP = 100;
numSamplePF = 500;

%状态转移矩阵
statTransSca = [1 0;timDelta 1];
statTrans = kron(statTransSca,eye(dim));
statInSca = [timDelta 1/2*timDelta^2]';
statIn = kron(statInSca,eye(dim));

numIter = 1e2;      % 迭代次数
minNum = 1e-9;      % 牛顿迭代阈值

%观测量方差
varDis = 1e-2;
varSpe = 1e-2;

devLocUpdateFinal = zeros(2,numMea);
devLocKal_Final = zeros(2,numMea);
devLocPF_Final = zeros(2,numMea);
devLocSCKF_Final = zeros(numVair,numMea);

%加速度部分
acc = zeros(dim,numMea+1);
accIni = 0*ones(dim,1);
% eta = sqrtm(varEta)*randn(dim,1);
acc(:,1) = accIni;
varEta = diag([1 1 1e-4]);1*eye(dim);

crbFinal = zeros(2,numMea);
varEKFFinal = zeros(2,numMea);
% crbIniIdx = diag(varEta);
crbIniIdx = 1*ones(2,1);
crbFinal(:,1) = crbIniIdx;
varEKFFinal(:,1) = crbIniIdx;
devLocUpdateFinal(:,1) = crbIniIdx;
devLocKal_Final(:,1) = crbIniIdx;

lam = 0; %MA模型系数

varStatFir = eye(numElement);
nodeLocUpdate(:,1) = sqrtm(varStatFir)*randn(numElement,1);
nodeLocEst(:,1) = nodeLocUpdate(dim+1:2*dim,1);


monTimesReal = monTimes;

for monIdx = 1:1:monTimes
%     monIdx
    tic
    for meaIdx = 2:1:numMea
        eta = sqrtm(varEta)*randn(dim,1);
        acc(:,meaIdx) = lam^(meaIdx-1)*accIni + eta;
        nodeLocUpdate(:,meaIdx) = statTrans*nodeLocUpdate(:,meaIdx-1) + statIn*acc(:,meaIdx-1);
    end

    % 锚点位置
    networkLim = zeros(dim,2);
    for idx = 1:dim
        networkLim(idx,1) = min(nodeLocUpdate(dim+idx,:));
        networkLim(idx,2) = max(nodeLocUpdate(dim+idx,:));
    end

    squSize = 2e3;
   
    for idx = 1:dim
        networkLim(idx,1) = floor(networkLim(idx,1))-delPosAP;
    end

    networkLim(1,2) = networkLim(1,1) + squSize;
    networkLim(2,2) = networkLim(2,1) + squSize;
    networkLim(3,2) = networkLim(3,1) + 2*delPosAP;
%     numGrid = squSize/delOrder;

    dim1 = (networkLim(1,1):delPosAP:networkLim(1,2));
    dim2 = (networkLim(2,1):delPosAP:networkLim(2,2));
    dim3 = (networkLim(3,1):delPosAP:networkLim(3,2));

    L1 = length(dim1);
    L2 = length(dim2);
    L3 = length(dim3);

    numAP = L1*L2*L3;
    posAP = zeros(dim,numAP);
    
    sign = 1;
    for idx1 = 1:L1
        for idx2 = 1:L2
            for idx3 = 1:L3
                posAP(:,sign) = [dim1(idx1) dim2(idx2) dim3(idx3)]';
                sign = sign + 1;
            end
        end
    end
    1;


    crbTol = zeros(numElement,numMea);
    crbIdx = zeros(numElement,numElement,numMea);
    crbIdx(:,:,1) = eye(numElement);
    locErr = zeros(2,numIter,numMea);
    devLocUpdate = zeros(2,numMea);
    nodeLoc_last = randn(2*dim,1);nodeLocUpdate(:,1) + randn(2*dim,1);
    R_tol = zeros(2*dim,2*dim*numMea);
    R_tol(:,2*dim+1:2*dim*2) = statTrans*eye(2*dim)*statTrans' + lam^2*statIn*varEta*statIn';

    %   EKF - initialize the variables
    statForeEKF = zeros(2*dim,numMea);
    statForeEKF(:,1) = randn(2*dim,1);
    statEstEKF = zeros(2*dim,numMea+1);
    statEstEKF(:,1) = randn(2*dim,1);nodeLocUpdate(:,1) + randn(2*dim,1);
    devLocKal = zeros(2,numMea);
    P = eye(2*dim);

    %   SCKF - initialize the variables
    statForeSCKF = zeros(2*dim,numMea);
    statForeSCKF(:,1) = randn(2*dim,1);
    statEstSCKF = zeros(2*dim,numMea+1);
    statEstSCKF(:,1) = randn(2*dim,1);
    devLocSCKF = zeros(2,numMea);

    %       PF - initialize the variables
    
    nodeLocPF_Sample = zeros(numElement,numSamplePF);
    for PFstep = 1:1:numSamplePF
        nodeLocPF_Sample(:,PFstep) = randn(2*dim,1);nodeLocUpdate(:,1) + sqrt(varStatFir)*randn(numElement,1);
    end
    meaUpdatePF = zeros(2,numSamplePF);
    preWeightPF = zeros(1,numSamplePF);
    nodeEstPF = zeros(numElement,numMea);
    nodeEstPF(:,1) = randn(2*dim,1);
    devLocPF = zeros(2,numMea);

    untIdx = zeros(numIter,numMea);

    for meaIdx = 2:1:numMea
        %         meaIdx
        lamIdx = 0;
        for jj = 0:meaIdx-3
            lamIdx = lamIdx + lam^(2*jj);
        end

        % 随机寻找最近的k个AP中的一个
        relDisIdx = zeros(numAP,1);
        for idx = 1:numAP
            relDisIdx(idx) = norm(nodeLocUpdate(dim+1:end,meaIdx)-posAP(:,idx));
        end

        [~,sign] = mink(relDisIdx,10);
        sign = randsrc(1,1,sign');
        
        % 测量
        posAnc = posAP(:,sign); %锚点位置

%         posAnc = nodeLocUpdate(dim+1:numElement,meaIdx) + ones(dim,1) + 10*randn(dim,1); %锚点位置
        varMeas = [varDis;varSpe];
        noiMeas = sqrt(varMeas).*randn(2,1);
        measTol = mea_trans(nodeLocUpdate(:,meaIdx),posAnc,dim); %距离与相对速度关系式（测量量）
        measTol = measTol + noiMeas;  %加噪声后的测量量

        %EKF
        statForeEKF(:,meaIdx) = statTrans*statEstEKF(:,meaIdx-1) + lam^(meaIdx-2)*statIn*accIni;
        P_fore = statTrans*P*statTrans'+ lamIdx*statIn*varEta*statIn';
        h = partial_h(statForeEKF(:,meaIdx),posAnc,dim);
        K = P_fore*h'/(h*P_fore*h'+ kron(diag(varMeas),eye(numPoc)));
        statEstEKF(:,meaIdx) = statForeEKF(:,meaIdx) + K*(measTol - mea_trans(statForeEKF(:,meaIdx),posAnc,dim));
        P = (eye(2*dim)-K*h)*P_fore*(eye(2*dim)-K*h)'+ K*diag(varMeas)*K';
        varEKFIdx = diag(P);
        varEKFFinal(1,meaIdx) = varEKFFinal(1,meaIdx) + sum(varEKFIdx(1:dim));
        varEKFFinal(2,meaIdx) = varEKFFinal(2,meaIdx) + sum(varEKFIdx(dim+1:2*dim));
        devLocKal(1,meaIdx) = norm(statEstEKF(1:dim,meaIdx) - nodeLocUpdate(1:dim,meaIdx))^2;
        devLocKal(2,meaIdx) = norm(statEstEKF(dim+1:2*dim,meaIdx) - nodeLocUpdate(dim+1:2*dim,meaIdx))^2;

        %SCKF
        PSCKF = R_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx);
        statForeSCKF(:,meaIdx) = statTrans*statEstSCKF(:,meaIdx-1) + lam^(meaIdx-2)*statIn*accIni;
        P_fore = statTrans*PSCKF*statTrans'+ lamIdx*statIn*varEta*statIn';
        h = partial_h(statForeSCKF(:,meaIdx),posAnc,dim);
        K = P_fore*h'/(h*P_fore*h'+ kron(diag(varMeas),eye(numPoc)));
        statEstSCKF(:,meaIdx) = statForeSCKF(:,meaIdx) + K*(measTol - mea_trans(statForeSCKF(:,meaIdx),posAnc,dim));
        devLocSCKF(1,meaIdx) = norm(statEstSCKF(1:dim,meaIdx) - nodeLocUpdate(1:dim,meaIdx))^2;
        devLocSCKF(2,meaIdx) = norm(statEstSCKF(dim+1:2*dim,meaIdx) - nodeLocUpdate(dim+1:2*dim,meaIdx))^2;


        %      PF
        for PFstep = 1:1:numSamplePF
            etaPF = sqrtm(varEta)*randn(dim,1);
            accPF = lam^meaIdx*accIni + etaPF;
            nodeLocPF_Sample(:,PFstep) = statTrans*nodeLocPF_Sample(:,PFstep) + statIn*accPF;
            meaUpdatePF(:,PFstep) = mea_trans(nodeLocPF_Sample(:,PFstep),posAnc,dim);
            Q = varMeas.*eye(2);
            preWeightPF(PFstep) = 1e-24 + 1/sqrt((2*pi)^2*det(Q)) * exp(-1/2*(measTol - meaUpdatePF(:,PFstep))'*(Q\(measTol - meaUpdatePF(:,PFstep))));
%             if preWeightPF(PFstep) == 0
%                 preWeightPF(PFstep) = 1e-24;
%             end
        end
        preWeightPF = preWeightPF/sum(preWeightPF);
        RPF = cumsum(preWeightPF,2);
        TPF = rand(1,numSamplePF);
        [~,~,reSamStep1] = histcounts(TPF,RPF);
        nodeLocPF_Sample = nodeLocPF_Sample(:,reSamStep1+1);
%         for PFstep = 1:1:numSamplePF
%             nodeLocPF_Sample(:,PFstep) = nodeLocPF_Sample(:,find(rand <= cumsum(preWeightPF,2),1));   % 粒子权重大的将多得到后代
%         end

        nodeEstPF(:,meaIdx) = sum(nodeLocPF_Sample,2)/numSamplePF;
        devLocPF(1,meaIdx) = norm(nodeEstPF(1:dim,meaIdx) - nodeLocUpdate(1:dim,meaIdx))^2;
        devLocPF(2,meaIdx) = norm(nodeEstPF(dim+1:2*dim,meaIdx) - nodeLocUpdate(dim+1:2*dim,meaIdx))^2;

        % CKF
        nodeLoc_pre = nodeLoc_last;
        for nn = 1:1:numIter
            [df,Hes] = Hessian_Gau(measTol,nodeLoc_pre,posAnc,dim,varMeas,nodeLoc_last,R_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),statTrans,statIn,accIni,meaIdx,lam);
            if isnan(Hes)
                flag = 1;
                break
            end
            Hes = (Hes+Hes')/2;
            [V,S] = eig(Hes);
            ev = diag(S);
            V1 = V(:,ev>0);
            e1 = ev(ev>0);
            u_nt = -V1*((V1'*df)./e1);

            % 回溯直线法 alpha∈[0.01,0.3],beta∈[0.1,0.8]
            step = 1;
            alpha = 0.03;
            beta = 0.8;
            while 1
                nodeLoc_delta = nodeLoc_pre + step*u_nt;
                f = f_ML_Gau(measTol,nodeLoc_pre,posAnc,dim,varMeas,nodeLoc_last,R_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),statTrans,statIn,accIni,meaIdx,lam);
                f_delta = f_ML_Gau(measTol,nodeLoc_delta,posAnc,dim,varMeas,nodeLoc_last,R_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),statTrans,statIn,accIni,meaIdx,lam);
                stt = alpha*step*df'*u_nt;
                sss = f + stt;
                if f_delta > sss
                    step = beta*step;
                else
                    break
                end
            end
            nodeLoc_pre = nodeLoc_delta;

            locErr(1,nn,meaIdx) = norm(nodeLoc_pre(1:dim) - nodeLocUpdate(1:dim,meaIdx))^2;
            locErr(2,nn,meaIdx) = norm(nodeLoc_pre(dim+1:2*dim) - nodeLocUpdate(dim+1:2*dim,meaIdx))^2;
            %             locErr(2,nn,meaIdx)
            %             1;
            untIdx (nn,meaIdx) = u_nt'*u_nt;
            if u_nt'*u_nt < minNum       % 梯度下降减量足够小时提前减少迭代
                break
            end


        end
        %         c = u_nt'*u_nt;
        1;
        if nn == numIter
            flag = 1;
            fprintf('The NO.%.0f point does not converge completely.\n',meaIdx)
        end
        devLocUpdate(:,meaIdx) = locErr(:,nn,meaIdx);
        RIdx = statTrans*crbIdx(:,:,meaIdx-1)*statTrans' + lamIdx*statIn*varEta*statIn';
        [crb,flag1] = CRB_Gaussian(nodeLoc_pre,posAnc,varMeas,R_tol(:,2*dim*(meaIdx-1)+1:2*dim*meaIdx),dim);
        crbIdx(:,:,meaIdx) = crb;

        crbTol(:,meaIdx) = diag(crb);
        crbFinal(1,meaIdx) = crbFinal(1,meaIdx) + sum(crbTol(1:dim,meaIdx));
        crbFinal(2,meaIdx) = crbFinal(2,meaIdx) + sum(crbTol(dim+1:2*dim,meaIdx));

        lamIdxNext = 0;
        for jj = 0:meaIdx-2
            lamIdxNext = lamIdxNext + lam^(2*jj);
        end

        R_tol(:,2*dim*meaIdx+1:2*dim*(meaIdx+1)) = statTrans*crb*statTrans' + lamIdxNext*statIn*varEta*statIn';
        nodeLoc_last = nodeLoc_pre;
        nodeLocEst(:,meaIdx) = nodeLoc_pre(dim+1:2*dim);


    end
    devLocUpdateFinal = devLocUpdateFinal + devLocUpdate;
    devLocKal_Final = devLocKal_Final + devLocKal;
    devLocSCKF_Final = devLocSCKF_Final + devLocSCKF;
    devLocPF_Final = devLocPF_Final + devLocPF;
    fprintf('the numer of Monte Carlo is%6.1f\n',monIdx)
    toc
end

devLocUpdateFinal = sqrt(devLocUpdateFinal/monTimesReal);
crbFinal = sqrt(crbFinal/monTimesReal);
varEKFFinal = sqrt(varEKFFinal/monTimesReal);
devLocKal_Final = sqrt(devLocKal_Final/monTimesReal);
devLocPF_Final = sqrt(devLocPF_Final/monTimesReal);
devLocSCKF_Final = sqrt(devLocSCKF_Final/monTimesReal);

Time = (2*timDelta:timDelta:numMea*timDelta);
figure
subplot(2,1,1)
plot(Time,devLocUpdateFinal(1,2:end),'b','linewidth',2.3);
hold on
plot(Time,devLocSCKF_Final(1,2:end),'m','linewidth',2.3);
hold on
plot(Time,devLocKal_Final(1,2:end),'color',[0.00,0.79,0.14],'linewidth',2.3);
hold on
plot(Time,devLocPF_Final(1,2:end),'color',[0.93,0.69,0.13],'linewidth',2.3);
hold on
plot(Time,crbFinal(1,2:end),'r','linestyle','--','linewidth',2.3);
hold on
ylabel('RMSE (m/s)')
xlabel('Time (s)')
legend('CKF','SCKF','EKF','PF','CRB-CKF')
title('Velocity Estimation')
set(gca,'FontSize',13);
grid on
hold on

subplot(2,1,2)
plot(Time,devLocUpdateFinal(2,2:end),'b','linewidth',2.3);
hold on
plot(Time,devLocSCKF_Final(2,2:end),'m','linewidth',2.3);
hold on
plot(Time,devLocKal_Final(2,2:end),'color',[0.00,0.79,0.14],'linewidth',2.3);
hold on
plot(Time,devLocPF_Final(2,2:end),'color',[0.93,0.69,0.13],'linewidth',2.3);
hold on
plot(Time,crbFinal(2,2:end),'r','linestyle','--','linewidth',2.3);
hold on
ylabel('RMSE (m)')
xlabel('Time (s)')
legend('CKF','SCKF','EKF','PF','CRB-CKF')
title('Position Estimation')
set(gca,'FontSize',13);
grid on
1;
name = ['Gaussian_a=' num2str(varEta(1)) ';gridDel=' num2str(delPosAP) ';varMea=' num2str(varDis)...
    ';DeltaT=' num2str(timDelta) ';MonTimes=' num2str(monTimesReal) ';numSampPF=' num2str(numSamplePF) '.fig'];
saveas(gcf,name);