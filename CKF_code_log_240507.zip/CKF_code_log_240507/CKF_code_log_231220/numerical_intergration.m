clear
% rng(123)
dim = 3; %维度
numElement = 2*dim;
numMea = 500;   %测量次数
numVair = 2;    %观测量个数
monTimes = 5e3;
numPoc = 1;
%加速度部分
numGau = 3;
varPhiInit = zeros(numGau,1);

timDelta = 0.05;    %两个锚点测量时的时间间隔

delPosAP = 100; %传感器间隔
squSize = 2e3; %C_V2X 网络大小


varDis = 1e-2; %观测量方差
varSpe = 1;

varPhiInit(1) = 1e-1; %输入量方差
varPhiInit(2) = 1e-1;
varPhiInit(3) = 0;

phiMeanInit1 = [2 2 0]'; %输入量均值
phiMeanInit2 = [-2 -2 0]';
phiMeanInit3 = zeros(dim,1);

Prob1 = 0.2;
Prob2 = 0.2;
Prob3 = 1 - Prob1 - Prob2;
Prob = [Prob1 Prob2 Prob3];


devLocUpdateFinal = zeros(numVair,numMea);
devLocCubKF_Final = zeros(numVair,numMea);
devLocKal_Final = zeros(numVair,numMea);
devLocPF_Final = zeros(numVair,numMea);
devLocSCKF_Final = zeros(numVair,numMea);
devLocUKF_Final = zeros(numVair,numMea);
devLocSRCKF_Final = zeros(numVair,numMea);

%状态转移矩阵
statTransSca = [1 0;timDelta 1];
statTrans = kron(statTransSca,eye(dim));
statInSca = [timDelta 1/2*timDelta^2]';
statIn = kron(statInSca,eye(dim));

acc = zeros(dim,numMea+1);
accMean = zeros(3*dim,numMea+1);
varAcc1 = zeros(dim,numMea+1);
varAcc2 = zeros(dim,numMea+1);
varAcc3 = zeros(dim,numMea+1);
varAcc1(:,1) = varPhiInit(1)*ones(dim,1);
varAcc2(:,1) = varPhiInit(2)*ones(dim,1);
varAcc3(:,1) = varPhiInit(3)*ones(dim,1);

phiPdf1 = phiMeanInit1 + sqrt(varPhiInit(1))*randn(dim,1);
phiPdf2 = phiMeanInit2 + sqrt(varPhiInit(2))*randn(dim,1);
phiPdf3 = phiMeanInit3 + sqrt(varPhiInit(3))*randn(dim,1);

chi = randsrc(dim,1,[1,2,3;Prob1,Prob2,Prob3]);
phiPdf = zeros(dim,numMea+1);
phiMean = zeros(dim,numMea+1);%输入的均值

phiPdf(:,1) = phiPdf1.*(chi==1)+phiPdf2.*(chi==2)+phiPdf3.*(chi==3);
acc(:,1) = phiPdf(:,1);
accMean(:,1) = [phiMeanInit1' phiMeanInit2' phiMeanInit3']';


varStatFir = varPhiInit(1);
nodeLocUpdate = zeros(numElement,numMea+1);
nodeLocUpdate(:,1) = zeros(numElement,1);



num = 3;
data = zeros(numElement,num);
noise = zeros(numElement,num);
for j = 2:1:num+1
    chi = randsrc(numElement,1,[1,2,3;Prob1,Prob2,Prob3]);
    pdf1 = statIn*accMean1 + real(sqrtm(R_tol))*randn(numElement,1);
    pdf2 = statIn*accMean2 + real(sqrtm(M_tol))*randn(numElement,1);
    pdf3 = statIn*accMean3 + real(sqrtm(S_tol))*randn(numElement,1);
    noise(:,j-1) = pdf1.*(chi==1)+pdf2.*(chi==2)+pdf3.*(chi==3);
    data(:,j-1) = statTrans*nodeLoc_last + noise(:,j-1);
end