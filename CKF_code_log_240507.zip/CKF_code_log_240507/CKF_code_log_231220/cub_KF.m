function [stateUpd, P1] = cub_KF(varMeas,dim,posAnc,measTol,delAccMean,delAccVar,statTrans,statIn,nodeLoc_last1,P1,numElement)
varphi = sqrt(numElement)*[eye(numElement) -eye(numElement)];
% 预测
% 生成cubature点
cubaturePointNum = 2*numElement;
choleskyDecompose = chol(P1,'lower');% 协方差矩阵方根

state_CP = zeros(numElement,cubaturePointNum); % cubature点状态
for iCubaturePoint = 1:cubaturePointNum
    state_CP(:,iCubaturePoint) = nodeLoc_last1 + choleskyDecompose*varphi(:,iCubaturePoint);
end

weight_CP = 1/cubaturePointNum.*ones(1,cubaturePointNum); % cubature点权重

% cubature点状态预测
cubaturePoint_num = size(state_CP,2);
statePre_CP = zeros(numElement,cubaturePoint_num);
for idx = 1:cubaturePoint_num
    statePre_CP(:,idx) = statTrans*state_CP(:,idx) + statIn*delAccMean;
end
% 目标状态预测
statePre = statePre_CP*weight_CP';
% 预测协方差
covarPre = zeros(numElement,numElement);
for idx = 1:cubaturePoint_num
    %             covarPre = covarPre + weight_CP(1,idx)*(statePre_CP(:,idx)-statePre)*(statePre_CP(:,idx)-statePre)';
    covarPre = covarPre + statePre_CP(:,idx)*statePre_CP(:,idx)';
end
covarPre = covarPre/cubaturePoint_num - statePre*statePre';

covarPre = covarPre + statIn*delAccVar*statIn';

% 更新
% 获取先验状态的cubature点
choleskyDecompose = chol(covarPre,'lower');

stateUpdate_CP = zeros(numElement,cubaturePointNum);% cubature点状态
for iCubaturePoint = 1:cubaturePointNum
    stateUpdate_CP(:,iCubaturePoint) = statePre + choleskyDecompose*varphi(:,iCubaturePoint);
end
% 观测预测
measPre_CP = zeros(length(measTol),cubaturePointNum);
for idx = 1:cubaturePointNum
    measPre_CP(:,idx) = mea_trans(stateUpdate_CP(:,idx),posAnc,dim);
end
measPre = measPre_CP*weight_CP';
% 观测预测协方差
Covar = zeros(numElement,length(measTol));
Scov = zeros(length(measTol),length(measTol));
sigmaPoint_num = size(state_CP,2);
for idx = 1:sigmaPoint_num
    %             Covar = Covar + weight_CP(idx)*(stateUpdate_CP(:,idx)-statePre)*(measPre_CP(:,idx)-measPre)';
    %             Scov = Scov + weight_CP(idx)*(measPre_CP(:,idx)-measPre)*(measPre_CP(:,idx)-measPre)';
    Covar = Covar + stateUpdate_CP(:,idx)*measPre_CP(:,idx)';
    Scov = Scov + measPre_CP(:,idx)*measPre_CP(:,idx)';
end
Covar = Covar/sigmaPoint_num - statePre*measPre';
Scov = Scov/sigmaPoint_num - measPre*measPre';

Scov = Scov + diag(varMeas);

K1 = Covar/Scov;
stateUpd = statePre + K1*(measTol-measPre);
% 协方差更新
P1 = covarPre - K1*Scov*K1';
%         P1 = covarPre - K*Covar';