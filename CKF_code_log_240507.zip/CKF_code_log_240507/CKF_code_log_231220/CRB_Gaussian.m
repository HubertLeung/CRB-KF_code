function [crb,flag] = CRB_Gaussian(nodeLoc_pre,posAnc,varMeas,RIdx,dim)
numElement = 2*dim;
du = zeros(2,numElement);
Q = diag(varMeas);
t = 0;
pk = posAnc;
y = nodeLoc_pre(1:dim);
x = nodeLoc_pre(dim+1:2*dim);
s = x - pk; 

dhx_1 = s/norm(s);
dhx_2 = y/norm(s) - s'*y*s/norm(s)^3;

dhy_1 = t*s/norm(s);
dhy_2 = (s+t*y)/norm(s) - s'*y*s*t/norm(s)^3;

du(1,:) = -[dhy_1' dhx_1']; 
du(2,:) = -[dhy_2' dhx_2']; 

F1 = du'*(Q\du);

F = F1 + inv(RIdx);
1;
flag = 0;
if sum(isnan(F),'all') > 0 || sum(isinf(F),'all') > 0
    flag = 1;
end
if norm(F) > 1e5
    flag = 1;
    crb = eye(numElement);
else
    crb = real(F\eye(numElement));
end

