clc
clear
dim = 3; %维度
numElement = 2*dim;
numMea = 2e3;   %测量次数
numVair = 2; %观测量个数
monTimes = 1e3;
numPoc = 1;
%加速度部分
numGau = 3;
varPhiInit = zeros(numGau,1);

varDis = 0.01; %观测量方差
varSpe = 1;

delPosAP = 100;  %锚点间距

varPhiInit(1) = 1e-2; %输入量方差
varPhiInit(2) = 1e-2;
varPhiInit(3) = 0;

phiMeanInit1 = [2 2 0]'; %输入量均值
phiMeanInit2 = [-2 -2 0]';
phiMeanInit3 = zeros(dim,1);

timDelta = 0.2;

Prob1 = 0.2;
Prob2 = 0.2;
Prob3 = 1 - Prob1 - Prob2;
Prob = [Prob1 Prob2 Prob3];

numIter = 1e2;      % 迭代次数
minNum = 1e-6;      % 牛顿迭代阈值
devLocUpdateFinal = zeros(numVair,numMea);
devLocSCKF_Final = zeros(numVair,numMea);

acc = zeros(dim,numMea+1);
accMean = zeros(3*dim,numMea+1);
varAcc1 = zeros(dim,numMea+1);
varAcc2 = zeros(dim,numMea+1);
varAcc3 = zeros(dim,numMea+1);
varAcc1(:,1) = varPhiInit(1)*ones(dim,1);
varAcc2(:,1) = varPhiInit(2)*ones(dim,1);
varAcc3(:,1) = varPhiInit(3)*ones(dim,1);

phiPdf1 = phiMeanInit1 + sqrt(varPhiInit(1))*randn(dim,1);
phiPdf2 = phiMeanInit2 + sqrt(varPhiInit(2))*randn(dim,1);
phiPdf3 = phiMeanInit3 + sqrt(varPhiInit(3))*randn(dim,1);

chi = randsrc(dim,1,[1,2,3;Prob1,Prob2,Prob3]);
phiPdf = zeros(dim,numMea+1);
phiMean = zeros(dim,numMea+1);%输入的均值
varPhi = zeros(dim,numMea+1);
varPhi(:,1) = varPhiInit(1:dim);
phiPdf(:,1) = phiPdf1.*(chi==1)+phiPdf2.*(chi==2)+phiPdf3.*(chi==3);
acc(:,1) = phiPdf(:,1);
accMean(:,1) = [phiMeanInit1' phiMeanInit2' phiMeanInit3']';

nodeLocUpdate = zeros(numElement,numMea+1);
nodeLocUpdate(:,1) = [0 0 0 5 5 0.1]';

%状态转移矩阵
statTransSca = [1 0;timDelta 1];
statTrans = kron(statTransSca,eye(dim));
statInSca = [timDelta 1/2*timDelta^2]';
statIn = kron(statInSca,eye(dim));
si = 1;
for meaIdx = 2:1:numMea+1
    chi = randsrc(dim,1,[1,2,3;Prob1,Prob2,Prob3]);
    phiPdf1 = phiMeanInit1 + sqrt(varPhiInit(1))*randn(dim,1);
    phiPdf2 = phiMeanInit2 + sqrt(varPhiInit(2))*randn(dim,1);
    phiPdf3 = phiMeanInit3 + sqrt(varPhiInit(3))*randn(dim,1);
    accMean(:,meaIdx) = accMean(:,1);
    acc(:,meaIdx) = phiPdf1.*(chi==1)+phiPdf2.*(chi==2)+phiPdf3.*(chi==3);

    varAcc1(:,meaIdx) = si^2*varAcc1(:,meaIdx-1) + varPhi(:,meaIdx);
    varAcc2(:,meaIdx) = si^2*varAcc2(:,meaIdx-1) + varPhi(:,meaIdx);
    varAcc3(:,meaIdx) = si^2*varAcc3(:,meaIdx-1) + varPhi(:,meaIdx);

    nodeLocUpdate(:,meaIdx) = statTrans*nodeLocUpdate(:,meaIdx-1) + statIn*acc(:,meaIdx-1);
end

%目标真实路径
for meaIdx = 2:1:numMea+1
    chi = randsrc(dim,1,[1,2,3;Prob1,Prob2,Prob3]);
    phiPdf1 = phiMeanInit1 + sqrt(varPhiInit(1))*randn(dim,1);
    phiPdf2 = phiMeanInit2 + sqrt(varPhiInit(2))*randn(dim,1);
    phiPdf3 = phiMeanInit3 + sqrt(varPhiInit(3))*randn(dim,1);
    accMean(:,meaIdx) = accMean(:,1);
    acc(:,meaIdx) = phiPdf1.*(chi==1)+phiPdf2.*(chi==2)+phiPdf3.*(chi==3);

    varAcc1(:,meaIdx) = si^2*varAcc1(:,meaIdx-1) + varPhi(:,meaIdx);
    varAcc2(:,meaIdx) = si^2*varAcc2(:,meaIdx-1) + varPhi(:,meaIdx);
    varAcc3(:,meaIdx) = si^2*varAcc3(:,meaIdx-1) + varPhi(:,meaIdx);

    nodeLocUpdate(:,meaIdx) = statTrans*nodeLocUpdate(:,meaIdx-1) + statIn*acc(:,meaIdx-1);
end

% 锚点位置
networkLim = zeros(dim,2);
for idx = 1:dim
    networkLim(idx,1) = min(nodeLocUpdate(dim+idx,:));
    networkLim(idx,2) = max(nodeLocUpdate(dim+idx,:));
end


squSize = 2e3;

for idx = 1:dim
    networkLim(idx,1) = floor(networkLim(idx,1))-delPosAP;
end

networkLim(1,2) = networkLim(1,1) + squSize;
networkLim(2,2) = networkLim(2,1) + squSize;
networkLim(3,2) = networkLim(3,1) + 2*delPosAP;
%     numGrid = squSize/delOrder;

dim1 = (networkLim(1,1):delPosAP:networkLim(1,2));
dim2 = (networkLim(2,1):delPosAP:networkLim(2,2));
dim3 = (networkLim(3,1):delPosAP:networkLim(3,2));

L1 = length(dim1);
L2 = length(dim2);
L3 = length(dim3);

numAP = L1*L2*L3;
posAP = zeros(dim,numAP);

sign = 1;
for idx1 = 1:L1
    for idx2 = 1:L2
        for idx3 = 1:L3
            posAP(:,sign) = [dim1(idx1) dim2(idx2) dim3(idx3)]';
            sign = sign + 1;
        end
    end
end

figure
for idx = 1:numAP
    plot3(posAP(1,idx),posAP(2,idx),posAP(3,idx),'ob')
    hold on
end

plot3(nodeLocUpdate(dim+1,1:end-1),nodeLocUpdate(dim+2,1:end-1),nodeLocUpdate(dim+3,1:end-1),'r','linewidth',1.5)
hold on

ylabel('dim_2 (m)')
xlabel('dim_1 (m)')
zlabel('dim_3 (m)')
grid on
