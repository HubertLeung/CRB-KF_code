        %EKF
        statForeEKF(:,meaIdx) = statTrans*statEstEKF(:,meaIdx-1) + Prob1*statIn*accMean(1:dim,meaIdx) + Prob2*statIn*accMean(dim+1:2*dim,meaIdx) + Prob3*statIn*accMean(2*dim+1:3*dim,meaIdx);
        weigSumMean = Prob1*accMean(1:dim,meaIdx) + Prob2*accMean(dim+1:2*dim,meaIdx) + Prob3*accMean(2*dim+1:3*dim,meaIdx);
        DeltaVar = Prob1*(accMean(1:dim,meaIdx)*accMean(1:dim,meaIdx)'+ R_acc) +  ...
            Prob2*(accMean(dim+1:2*dim,meaIdx)*accMean(dim+1:2*dim,meaIdx)' + M_acc) + ...
            Prob3*(accMean(2*dim+1:3*dim,meaIdx)*accMean(2*dim+1:3*dim,meaIdx)' +S_acc) - ...
            weigSumMean*weigSumMean';
        P_fore = statTrans*P*statTrans'+ statIn*DeltaVar*statIn';
        %         P_fore = statTrans*P*statTrans'+ statIn*(Prob1*R_acc + Prob2*M_acc + Prob3*S_acc)*statIn';
        h = partial_h(statForeEKF(:,meaIdx),posAnc,dim);
        K = P_fore*h'/(h*P_fore*h'+ kron(diag(varMeas),eye(numPoc)));
        statEstEKF(:,meaIdx) = statForeEKF(:,meaIdx) + K*(measTol - mea_trans(statForeEKF(:,meaIdx),posAnc,dim));
        P = (eye(2*dim)-K*h)*P_fore*(eye(2*dim)-K*h)'+ K*diag(varMeas)*K';
